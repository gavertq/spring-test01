package com.care.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class animationController {
	
	@RequestMapping("click")
	public String click() {
		return	"effect/animation_click";
	}
	
	@RequestMapping("circle")
	public String circle() {
		return	"effect/animation_circle";
	}
	
	@RequestMapping("rainbowEffect")
	public String rainbowEffect() {
		return "effect/rainbow_effect";
	}
	
	@RequestMapping("lightEffect")
	public String lightEffect() {
		return "effect/light_effect";
	}
	
	@RequestMapping("hoverEffect")
	public String hoverEffect() {
		return "effect/hoverEffect";
	}
	
	@RequestMapping("button")
	public String button() {
		return	"effect/animation_button";
	}
	
	@RequestMapping("menuEffect")
	public String menuEffect() {
		return "effect/menuEffect";
	}
	
	@RequestMapping("hamEffect")
	public String hamEffect() {
		return "effect/hamburgerIconEffect";
	}
	
	@RequestMapping("gooeyEffect")
	public String gooeyEffect() {
		return "effect/gooeyHoverMenuEffect";
	}
}
