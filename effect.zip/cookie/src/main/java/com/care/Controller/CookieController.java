package com.care.Controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CookieController {

	@RequestMapping("cookie")	
	public String myCookie(@CookieValue(value = "popCookie", required = false) Cookie cook, Model model) {
		
		if(cook != null) {	//popCookie라는 쿠키가 있다면
			model.addAttribute("popUpCookie", cook.getValue());	//그값을 Attribute에 저장
		}
	
		return "cookie";
	}
	
	@RequestMapping("popUp")	
	public String popUp() {
		return "popUp";
	}
	
	@RequestMapping("cookieChk")	
	public String cookieChk(HttpServletResponse response, Model model) {
		
		Cookie cook = new Cookie("popCookie", "체크");	//쿠키 생성
		cook.setMaxAge(10);	//쿠키 존재 시간
		cook.setPath("/");	//쿠키값을 모든 경로에서 접근 가능하도록.
		response.addCookie(cook);	//쿠키 적용
		
		model.addAttribute("result", "check");	//쿠키 생성 유무 확인을 위한 Attribute
		
		return "popUp";	//popUp으로 돌아감
	}
	
}
